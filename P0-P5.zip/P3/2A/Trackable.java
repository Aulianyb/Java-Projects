public interface Trackable {
    String getPlateNumber();
    Point getGPSPosition();
}
