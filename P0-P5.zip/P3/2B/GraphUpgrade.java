public interface GraphUpgrade {
    void shiftX(int shiftCount);
    void shiftY(int shiftCount);
    double distance(int x, int y);
}
