public interface Calculator {
    int add(int a, int b);
    int substract(int a, int b);
    int multiply(int a, int b);
    double divide(int a, int b);
    void start();
    void stop();
    int checkBattery();
}
