public interface Tyre {
    public String getTyreName();
    
    public int getTyrePressure();

    public int getTyreWidth();
}
