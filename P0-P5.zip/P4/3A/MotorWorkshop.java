public class MotorWorkshop {
    public void changeTyre(Motor motor, Tyre tyre) {
        motor.setTyre(tyre);
    }

    public void changeEngine(Motor motor, Engine engine) {
        motor.setEngine(engine);
    }
}
