public interface Engine {
    public int getEngineCapacity();

    public String sound();
}
