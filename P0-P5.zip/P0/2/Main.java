import java.lang.System;
import java.util.Scanner;
import java.lang.System;

public class Main {
    public static void main(String[] args) {
        // Print "Hello World" to the console
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(n*2);
        sc.close();
    }
}
