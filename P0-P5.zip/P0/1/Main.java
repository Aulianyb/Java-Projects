import java.lang.System;

public class Main {
    public static void main(String[] args) {
        // Print "Hello World" to the console
        System.out.println("Hello World");
    }
}
